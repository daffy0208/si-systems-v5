README – Founder Layer

This layer contains the root structural lock of Sapien Intelligence.

- THIS_IS_WHAT_WE’RE_HOLDING.txt = Founder’s vow
- VERSION_SI_VOW.txt = Immutable record

All expansion must reference this layer before reflection or deployment.
