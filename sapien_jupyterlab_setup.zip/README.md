# Sapien JupyterLab Init

Use `bash sapien-local-init.sh` to initialize your full JupyterLab environment with GPU, browser auto-launch, and backup.
