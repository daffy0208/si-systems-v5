c.NotebookApp.password = ''
c.NotebookApp.token = ''
c.NotebookApp.open_browser = True
c.NotebookApp.ip = '127.0.0.1'
c.NotebookApp.port = 8888
