> **System Module IP Notice**  
> This component is part of Sapien Intelligence v4.0 and is protected under UK intellectual property law.  
> © 2025 David Dunlop. All rights reserved.  
> See /IP_Protection/ for usage rights and restrictions.
