# Trust Map

Trust in Sapien Intelligence is not assumed — it is earned structurally.

The system maps trust across:

- **Source Integrity**: Is the origin of the signal traceable, clean, and reflective?
- **Fidelity Path**: Has the data, decision, or reflection passed through drift-safe conditions?
- **Alignment Check**: Is the output in alignment with stated WHY / WHAT / HOW?

The Trust Map defines three zones:

1. **Coherent Trust**: Fully aligned with system promise, field logic, and user rhythm.
2. **Conditional Trust**: Temporarily valid but requires validation scan (e.g. TDC).
3. **Drifted Trust**: Out of alignment with system purpose or fidelity layer.

Trust is not static — it is dynamic and continually re-evaluated through reflective loops and system rituals.
