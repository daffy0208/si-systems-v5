# System Rights and Restrictions

## Rights:

- Users have the right to full access of their WHY across all interfaces
- No system component may override the user’s identity rhythm
- All data reflections must be traceable, editable, and symbolically coherent

## Restrictions:

- No promise can be made that the system cannot fulfill  
- All drift must trigger a reflective check or lock  
- Derivative systems must retain origin signal unless explicitly redefined

This document protects the sovereign emotional field of any user engaging with Sapien.
