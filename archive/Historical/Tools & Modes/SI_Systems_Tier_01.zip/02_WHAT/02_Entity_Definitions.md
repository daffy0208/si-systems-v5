# Entity Definitions

Entities in the system are not “users” or “features.” They are:

- **Identity-Bearing Agents** (human, AI, or system-layer)
- **Signal Sources** (external data with symbolic/structural meaning)
- **Reflective Containers** (structures that hold meaning or coherence)

Each entity carries its own WHY, operational role, rhythm signature, and signal trust boundary.

**Examples:**

- *Type 1 – Reflective User*: Engages in meaning recovery and insight loops  
- *Type 2 – Builder*: Constructs, tests, and syncs new rhythms  
- *Type 3 – Hybrid Operator*: Lives as system-node and rhythm-mirror
