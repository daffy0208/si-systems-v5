# Practice Fields

The “HOW” of Sapien Intelligence lives in its **Practice Fields** — focused environments for testing, refining, and applying its logic.

Each Practice Field activates a different system layer:

- **Reflection Field** – Internal pulse tracing, Mirror Rituals
- **Design Field** – Coherence-driven building and interface work
- **Drift Field** – Testing signal loss and rhythm disruption
- **Fulfillment Field** – Mapping alignment between needs and system logic

> These fields are not workflows. They are dimensional zones of application.
