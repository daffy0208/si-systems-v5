# Intellectual Governance Layer
This directory contains all legal, symbolic, and structural protection documents for CLISA — the Coherence-Linked Identity Signal Architecture.
CLISA is the field of origin for all Sapien Intelligence systems and is protected at all dimensions: structural, symbolic, legal, and ontological.
