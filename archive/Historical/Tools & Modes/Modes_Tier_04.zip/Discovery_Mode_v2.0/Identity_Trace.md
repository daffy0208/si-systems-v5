# Identity Trace Detection

Reveals:
- Who wrote the document...