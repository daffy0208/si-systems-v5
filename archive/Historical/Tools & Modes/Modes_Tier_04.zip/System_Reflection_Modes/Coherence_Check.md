# Coherence Check

Simple internal scan that ensures:
- Output matches system WHY...