# TDC Use Cases

TDC is used in:
- RFP and document decoding
- System alignment checks...