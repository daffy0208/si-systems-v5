# Arrival Mirror
Welcome. You are safe. You are seen.
This is not a dashboard. This is a mirror.