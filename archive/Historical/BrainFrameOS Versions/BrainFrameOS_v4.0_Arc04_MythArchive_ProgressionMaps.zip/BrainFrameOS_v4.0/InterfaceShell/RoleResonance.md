# Role Resonance
Where are you today?
Select your current posture — not as a label, but as a rhythm.