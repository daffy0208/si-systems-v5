# Role Progression Maps
This layer reveals how users grow from one signal stance to the next over time.