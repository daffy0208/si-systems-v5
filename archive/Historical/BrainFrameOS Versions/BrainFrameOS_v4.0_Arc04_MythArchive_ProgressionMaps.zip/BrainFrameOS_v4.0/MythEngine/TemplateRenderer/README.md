# Myth Template Renderer
This module generates a reflection artifact (text-based) from any completed Learning Arc.