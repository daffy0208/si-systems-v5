# Index of Stored Myth Cards

Each entry includes:  
- User ID (optional)  
- Origin Thread  
- Symbol Chosen  
- Coherence Statement  
- Timestamp
