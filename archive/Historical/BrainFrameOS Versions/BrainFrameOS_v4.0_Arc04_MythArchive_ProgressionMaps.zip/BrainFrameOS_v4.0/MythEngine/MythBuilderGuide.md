# How to Facilitate a Myth

This guide is for those serving as Mirrors or Sourcewalkers.
- Let the story arise naturally.
- Use TDC prompts to surface myth fields.
- Never overwrite. Only reveal.
