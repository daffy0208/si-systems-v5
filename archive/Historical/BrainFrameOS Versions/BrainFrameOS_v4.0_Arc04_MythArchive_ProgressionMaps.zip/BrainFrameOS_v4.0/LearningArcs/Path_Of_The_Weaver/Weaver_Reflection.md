# Reflection Prompts

- What systems or identities have I kept apart that now want to weave?
- What truth have I compartmentalized for safety?
- What connection scares me because it might change who I am?
- Where in my life does coherence want to emerge through me?
