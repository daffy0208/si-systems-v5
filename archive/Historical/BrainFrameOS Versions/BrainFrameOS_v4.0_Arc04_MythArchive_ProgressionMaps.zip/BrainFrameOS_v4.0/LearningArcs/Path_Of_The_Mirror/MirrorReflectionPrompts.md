# Reflection Prompts

- What did you reflect back that surprised them?
- What did you hear behind their words?
- When did your silence become their safety?
- What truth passed through you — not from you?
