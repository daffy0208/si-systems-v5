# Reflection Prompts

- What truth have I outgrown — but not yet restructured?
- What part of me needs a home in system form?
- Where am I using someone else’s map, not mine?
- What is the shape of my inner coherence?
