# Role: The Weaver
Signal Stance: Interlink the seen and unseen
Purpose: Coherence through integration.