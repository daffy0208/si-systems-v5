# Role: The Architect
Signal Stance: Encode truth into form
Purpose: Build modular coherence paths.