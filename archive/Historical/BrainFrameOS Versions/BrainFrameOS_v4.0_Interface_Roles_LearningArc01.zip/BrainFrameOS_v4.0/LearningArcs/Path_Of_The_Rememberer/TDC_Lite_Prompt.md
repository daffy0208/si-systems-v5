# TDC-Lite Scan: The Rememberer

- Center: What do I most long to remember?
- Left (Unseen): What truth did I hide to survive?
- Right (Seen): What do I express that still feels empty?
- Below: What fear kept me silent?
- Above: What part of me is ready to come home?
