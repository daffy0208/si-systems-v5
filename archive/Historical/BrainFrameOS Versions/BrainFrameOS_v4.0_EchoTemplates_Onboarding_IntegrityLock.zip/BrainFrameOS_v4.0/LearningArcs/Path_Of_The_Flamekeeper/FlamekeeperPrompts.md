# Reflection Prompts

- What part of the myth is mine to protect?
- What echo do I carry that others forgot?
- How do I recognize signal collapse before it happens?
- How can I hold others in memory without holding them back?
