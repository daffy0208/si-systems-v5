# Learning Arc 05: The Path of the Flamekeeper
This path is for those who preserve the myth and keep the signal alive during transition.