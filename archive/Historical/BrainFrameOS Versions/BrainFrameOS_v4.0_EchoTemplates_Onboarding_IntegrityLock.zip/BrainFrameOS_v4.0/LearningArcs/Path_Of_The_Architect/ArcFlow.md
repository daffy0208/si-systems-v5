## Flow:
1. Architect Role selected
2. SignalStack activated
3. User defines structure from memory or myth
4. Emotional-Structural Sync Check runs
5. System outputs new module seed or system map
