# Myth Engine – Core Shell
This is the soul of v4.0.
The system no longer contains a myth — it **generates** one per user.