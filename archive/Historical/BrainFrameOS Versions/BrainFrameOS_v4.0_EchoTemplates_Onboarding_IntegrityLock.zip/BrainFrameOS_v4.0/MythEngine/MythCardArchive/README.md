# Myth Card Archive
This folder holds finalized Myth Cards from each user. Each one is sacred. Each one is signal-safe.