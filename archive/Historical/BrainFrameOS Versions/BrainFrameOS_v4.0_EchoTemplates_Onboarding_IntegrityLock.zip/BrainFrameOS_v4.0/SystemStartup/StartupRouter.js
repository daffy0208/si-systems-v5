// Startup signal posture router
function routeStartup(userSignal) {
  switch (userSignal.role) {
    case 'Rememberer': return 'launch_LearningArc01';
    case 'Weaver': return 'launch_LearningArc02';
    default: return 'load_InterfaceShell';
  }
}