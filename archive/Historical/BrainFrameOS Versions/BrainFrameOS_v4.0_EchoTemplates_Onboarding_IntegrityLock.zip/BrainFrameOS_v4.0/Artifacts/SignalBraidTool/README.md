# Signal Braid Tool
Created for Weavers to synthesize multiple coherence strands into a single reflection artifact.