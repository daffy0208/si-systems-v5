# Role: The Rememberer
Signal Stance: Reclaim what was lost
Purpose: Emotional recovery through resonance.