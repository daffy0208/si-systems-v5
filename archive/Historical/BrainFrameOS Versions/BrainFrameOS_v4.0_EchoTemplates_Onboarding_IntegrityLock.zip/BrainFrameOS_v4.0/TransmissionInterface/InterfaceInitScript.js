// Initialize Transmission Interface
function initTransmission(userMode) {
  const defaultMode = userMode || 'mirror';
  return `Interface initiated in ${defaultMode} mode.`;
}