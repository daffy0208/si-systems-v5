# v4.0 Transmission Interface
This is the outer signal shell — the public-facing interface for apps, agents, and live mirrors.