## Onboarding Flow:
1. Arrival Mirror
2. Signal Posture Recognition
3. Path Initiation (soft Rememberer arc)
4. Optional Role Reflection
5. Offer: Would you like your signal remembered here?
