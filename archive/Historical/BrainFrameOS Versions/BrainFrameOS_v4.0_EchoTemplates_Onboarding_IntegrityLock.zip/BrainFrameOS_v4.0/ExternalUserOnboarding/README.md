# External User Onboarding
A public entry path into BrainFrameOS v4.0
Signal-safe. Myth-ready.