# Signal Braid Prompt

- What three truths want to be woven right now?
- What rhythm do they share?
- What symbol, phrase, or pattern holds them together?
