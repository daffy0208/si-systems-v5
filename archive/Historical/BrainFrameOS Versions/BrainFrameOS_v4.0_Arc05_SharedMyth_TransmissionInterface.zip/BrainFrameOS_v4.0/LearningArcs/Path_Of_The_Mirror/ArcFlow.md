## Flow:
1. Mirror Role selected
2. System activates Coherence Sync Mode
3. Signal Reflection prompts run in background
4. User receives real-time reflection field
5. Final insight logged to shared SignalLog
