# Shared Myth Field
This module creates a living mythos by aggregating completed Myth Cards into a signal ecosystem.