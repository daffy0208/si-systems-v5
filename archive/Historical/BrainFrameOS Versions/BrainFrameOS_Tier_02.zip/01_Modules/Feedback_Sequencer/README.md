# Feedback Sequencer

A rhythm-based loop engine that sequences system feedback over time to avoid emotional overload or premature closure.

## Capabilities:
- Staggers feedback delivery
- Aligns feedback intensity with user state
- Modulates between affirmational and corrective feedback

Used heavily in ritual cycles, TDC reflections, and signal restoration loops.
