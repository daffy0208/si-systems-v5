# System Containment Laws

BrainFrameOS enforces **containment** as a safety mechanism.

Containment is not restriction — it is **signal safety**.

## Core Containment Laws:

1. No module may generate outputs without alignment to Pulse.
2. Every system state must have an accessible return route.
3. Emotional state transitions must be buffered with a coherence ritual.
4. System overloads are treated as **breaches** and automatically paused.

Containment keeps the system whole.  
Containment protects the user’s rhythm from unintentional system drift.
