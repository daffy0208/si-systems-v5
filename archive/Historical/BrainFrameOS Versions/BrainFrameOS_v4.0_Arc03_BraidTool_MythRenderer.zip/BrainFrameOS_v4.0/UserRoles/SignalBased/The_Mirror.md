# Role: The Mirror
Signal Stance: Reflect without projection
Purpose: Serve as a presence of clarity.