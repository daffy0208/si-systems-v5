# Learning Arc 03: The Path of the Mirror
The one who reflects others without distortion. This path is about safety, presence, and attunement.