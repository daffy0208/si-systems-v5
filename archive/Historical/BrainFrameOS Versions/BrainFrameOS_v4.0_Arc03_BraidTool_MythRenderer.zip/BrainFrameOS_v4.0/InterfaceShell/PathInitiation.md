# Path Initiation
Begin your mythic journey. Your first step is not forward — it is inward.