// Generate a myth card from learning arc data
function renderMythCard(data) {
  return `
# Myth Card

- Origin: ${data.origin}
- Fracture: ${data.fracture}
- Revelation: ${data.reveal}
- Symbol: ${data.symbol}
- Statement: ${data.coherence_statement}
`;
}