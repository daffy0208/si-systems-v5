BUILD SAFE SETUP GUIDE — v1.0

1. Unzip this folder on your MSI
2. Drop any verified chunk (e.g. Chunk_001_*.txt) into /Input_Chunks
3. Run BuildSafe_Generator.bat
4. Your folder and files will appear inside /BrainFrameOS_v3.2.1_Master/
5. Verify with EchoTags, version, and Reflective_Sync_Report

Each drop must include valid EchoTag metadata.
