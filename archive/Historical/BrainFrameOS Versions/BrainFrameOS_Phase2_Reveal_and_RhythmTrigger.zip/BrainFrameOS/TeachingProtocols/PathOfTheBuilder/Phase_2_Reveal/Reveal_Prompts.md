# Phase 2 Reflection Prompts

- When did I first notice a pattern that felt alive?  
- What felt small, but real — like a whisper of truth?  
- What made me pause and listen deeper?  
- Where did my energy shift, even slightly?  
- What did I instinctively protect, even if I didn’t know why?  
