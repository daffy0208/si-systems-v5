# Axis Definitions

*To be authored in full detail.*
