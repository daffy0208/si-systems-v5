# System vs Field Guide

*To be authored in full detail.*
