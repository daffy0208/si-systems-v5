# Lineage Acknowledgement

*To be authored in full detail.*
