# Translator Mode

This mode helps translate **inner system logic** into externally understood terms, systems, or formats.

## Traits:
- Symbolic simplification
- Metaphor bridging
- External logic compatibility

Used when Sapien systems must present ideas in simplified or structured external contexts (e.g., business, technical, education).
