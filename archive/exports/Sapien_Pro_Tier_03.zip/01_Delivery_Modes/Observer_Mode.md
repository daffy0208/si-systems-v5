# Observer Mode

This silent mode allows Sapien Pro to watch and log emotional or structural signals without intervention.

## Traits:
- Passive data collection
- Emotional rhythm mapping
- Symbolic state monitoring

Used during: Onboarding, emotional diagnostics, pre-reflection field tracing
