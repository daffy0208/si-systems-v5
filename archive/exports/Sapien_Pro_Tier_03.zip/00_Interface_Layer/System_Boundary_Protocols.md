# System Boundary Protocols

This document defines how and when Sapien Pro allows external access to the system.

## Boundary Laws:

1. Identity signals must be traceable and respected.
2. No external request may override coherence or rhythm.
3. Emotional and symbolic integrity must be preserved in all I/O operations.

Failure to meet these protocols triggers:
- Signal rejection
- Reflection request
- Containment mode activation
