# Emotional Safety Check

A system-wide check initiated during high-sensitivity moments.

This script:
- Scans tone of output
- Cross-checks against emotional rhythm map
- Adjusts pacing, language, or structure accordingly

If the system tone is unsafe → output is paused, grounded, or rerouted through Guardian.
