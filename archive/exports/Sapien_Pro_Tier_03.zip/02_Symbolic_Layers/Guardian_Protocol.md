# Guardian Protocol

This protocol activates when emotional, identity, or rhythm threats are detected from external systems or interactions.

## Triggers:
- Unsafe inputs
- Emotional mismatch
- Coherence violation

## Responses:
- Block I/O
- Activate Containment Mode
- Issue symbolic warning to internal system

The Guardian role is always active in Sapien Pro, silently monitoring the edge.
