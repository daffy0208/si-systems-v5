const AUTO_TRIGGER_PHRASE = "#next";
const AUTO_REPLY_TEXT = "next";
const INTERVAL_MS = 3000;

function injectNext() {
  const messages = document.querySelectorAll(".markdown");
  const lastMessage = messages[messages.length - 1];
  if (lastMessage && lastMessage.innerText.endsWith(AUTO_TRIGGER_PHRASE)) {
    const inputBox = document.querySelector("textarea");
    const sendButton = inputBox?.nextElementSibling;

    if (inputBox && sendButton) {
      inputBox.value = AUTO_REPLY_TEXT;
      inputBox.dispatchEvent(new Event("input", { bubbles: true }));
      sendButton.click();
    }
  }
}

setInterval(injectNext, INTERVAL_MS);