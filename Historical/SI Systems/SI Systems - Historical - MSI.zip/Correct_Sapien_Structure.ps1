$base = "$env:USERPROFILE\Documents\Sapien Intelligence"
$log = Join-Path $base "Logs\StructureFix_Log.txt"
"=== Folder Structure Fix Log - $(Get-Date) ===`n" | Out-File $log
$path = Join-Path $base "MirrorPyramid\Input"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] MirrorPyramid/Input" | Out-File $log -Append
} else {
    "[Exists] MirrorPyramid/Input" | Out-File $log -Append
}
$path = Join-Path $base "MirrorPyramid\Core\Identity_Engine"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] MirrorPyramid/Core/Identity_Engine" | Out-File $log -Append
} else {
    "[Exists] MirrorPyramid/Core/Identity_Engine" | Out-File $log -Append
}
$path = Join-Path $base "MirrorPyramid\Output\RoleInterfaces"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] MirrorPyramid/Output/RoleInterfaces" | Out-File $log -Append
} else {
    "[Exists] MirrorPyramid/Output/RoleInterfaces" | Out-File $log -Append
}
$path = Join-Path $base "MirrorPyramid\Output\Modules"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] MirrorPyramid/Output/Modules" | Out-File $log -Append
} else {
    "[Exists] MirrorPyramid/Output/Modules" | Out-File $log -Append
}
$path = Join-Path $base "System_Activation\Bootloader\START_HERE"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] System_Activation/Bootloader/START_HERE" | Out-File $log -Append
} else {
    "[Exists] System_Activation/Bootloader/START_HERE" | Out-File $log -Append
}
$path = Join-Path $base "System_Activation\IP_Protection"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] System_Activation/IP_Protection" | Out-File $log -Append
} else {
    "[Exists] System_Activation/IP_Protection" | Out-File $log -Append
}
$path = Join-Path $base "SystemMeta"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] SystemMeta" | Out-File $log -Append
} else {
    "[Exists] SystemMeta" | Out-File $log -Append
}
$path = Join-Path $base "MetaPhilosophy"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] MetaPhilosophy" | Out-File $log -Append
} else {
    "[Exists] MetaPhilosophy" | Out-File $log -Append
}
$path = Join-Path $base "AbstractModes"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] AbstractModes" | Out-File $log -Append
} else {
    "[Exists] AbstractModes" | Out-File $log -Append
}
$path = Join-Path $base "SourceFields"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] SourceFields" | Out-File $log -Append
} else {
    "[Exists] SourceFields" | Out-File $log -Append
}
$path = Join-Path $base "Tiers\Tier_0_Discovery"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Tiers/Tier_0_Discovery" | Out-File $log -Append
} else {
    "[Exists] Tiers/Tier_0_Discovery" | Out-File $log -Append
}
$path = Join-Path $base "Tiers\Tier_1_Reflection"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Tiers/Tier_1_Reflection" | Out-File $log -Append
} else {
    "[Exists] Tiers/Tier_1_Reflection" | Out-File $log -Append
}
$path = Join-Path $base "Tiers\Tier_2_Output"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Tiers/Tier_2_Output" | Out-File $log -Append
} else {
    "[Exists] Tiers/Tier_2_Output" | Out-File $log -Append
}
$path = Join-Path $base "Tiers\Tier_3_Integration"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Tiers/Tier_3_Integration" | Out-File $log -Append
} else {
    "[Exists] Tiers/Tier_3_Integration" | Out-File $log -Append
}
$path = Join-Path $base "Tiers\Tier_4_Mastery"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Tiers/Tier_4_Mastery" | Out-File $log -Append
} else {
    "[Exists] Tiers/Tier_4_Mastery" | Out-File $log -Append
}
$path = Join-Path $base "Tiers\Tier_5_Mirror"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Tiers/Tier_5_Mirror" | Out-File $log -Append
} else {
    "[Exists] Tiers/Tier_5_Mirror" | Out-File $log -Append
}
$path = Join-Path $base "Tiers\Tier_6_Transmission"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Tiers/Tier_6_Transmission" | Out-File $log -Append
} else {
    "[Exists] Tiers/Tier_6_Transmission" | Out-File $log -Append
}
$path = Join-Path $base "Tiers\Tier_7_Inheritance"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Tiers/Tier_7_Inheritance" | Out-File $log -Append
} else {
    "[Exists] Tiers/Tier_7_Inheritance" | Out-File $log -Append
}
$path = Join-Path $base "Tiers\Tier_8_Terraform"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Tiers/Tier_8_Terraform" | Out-File $log -Append
} else {
    "[Exists] Tiers/Tier_8_Terraform" | Out-File $log -Append
}
$path = Join-Path $base "Tiers\Tier_9_Singularity_Shield"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Tiers/Tier_9_Singularity_Shield" | Out-File $log -Append
} else {
    "[Exists] Tiers/Tier_9_Singularity_Shield" | Out-File $log -Append
}
$path = Join-Path $base "Tiers\Tier_10_Source_Loop"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Tiers/Tier_10_Source_Loop" | Out-File $log -Append
} else {
    "[Exists] Tiers/Tier_10_Source_Loop" | Out-File $log -Append
}
$path = Join-Path $base "Tier_Gateways"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Tier_Gateways" | Out-File $log -Append
} else {
    "[Exists] Tier_Gateways" | Out-File $log -Append
}
$path = Join-Path $base "Templates\Modules"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Templates/Modules" | Out-File $log -Append
} else {
    "[Exists] Templates/Modules" | Out-File $log -Append
}
$path = Join-Path $base "Templates\Roles"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Templates/Roles" | Out-File $log -Append
} else {
    "[Exists] Templates/Roles" | Out-File $log -Append
}
$path = Join-Path $base "Templates\Apps"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Templates/Apps" | Out-File $log -Append
} else {
    "[Exists] Templates/Apps" | Out-File $log -Append
}
$path = Join-Path $base "Templates\Bootloader"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Templates/Bootloader" | Out-File $log -Append
} else {
    "[Exists] Templates/Bootloader" | Out-File $log -Append
}
$path = Join-Path $base "Templates\GuestMode"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Templates/GuestMode" | Out-File $log -Append
} else {
    "[Exists] Templates/GuestMode" | Out-File $log -Append
}
$path = Join-Path $base "Archives\Heather_Personal_Build"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Archives/Heather_Personal_Build" | Out-File $log -Append
} else {
    "[Exists] Archives/Heather_Personal_Build" | Out-File $log -Append
}
$path = Join-Path $base "Archives\BrainFrame_v1"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Archives/BrainFrame_v1" | Out-File $log -Append
} else {
    "[Exists] Archives/BrainFrame_v1" | Out-File $log -Append
}
$path = Join-Path $base "Deployments"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Deployments" | Out-File $log -Append
} else {
    "[Exists] Deployments" | Out-File $log -Append
}
$path = Join-Path $base "Users"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Users" | Out-File $log -Append
} else {
    "[Exists] Users" | Out-File $log -Append
}
$path = Join-Path $base "Logs\2025\Q1"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Logs/2025/Q1" | Out-File $log -Append
} else {
    "[Exists] Logs/2025/Q1" | Out-File $log -Append
}
$path = Join-Path $base "Logs\2025\Q2"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Logs/2025/Q2" | Out-File $log -Append
} else {
    "[Exists] Logs/2025/Q2" | Out-File $log -Append
}
$path = Join-Path $base "Applications\Planning\Shadow_Planner_App"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Applications/Planning/Shadow_Planner_App" | Out-File $log -Append
} else {
    "[Exists] Applications/Planning/Shadow_Planner_App" | Out-File $log -Append
}
$path = Join-Path $base "Applications\Communication\Messaging_Lens_App"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Applications/Communication/Messaging_Lens_App" | Out-File $log -Append
} else {
    "[Exists] Applications/Communication/Messaging_Lens_App" | Out-File $log -Append
}
$path = Join-Path $base "Applications\Rhythm\Rhythm_Interface_App"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Applications/Rhythm/Rhythm_Interface_App" | Out-File $log -Append
} else {
    "[Exists] Applications/Rhythm/Rhythm_Interface_App" | Out-File $log -Append
}
$path = Join-Path $base "Applications\AI_Companions"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Applications/AI_Companions" | Out-File $log -Append
} else {
    "[Exists] Applications/AI_Companions" | Out-File $log -Append
}
$path = Join-Path $base "Applications\DataTools"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Applications/DataTools" | Out-File $log -Append
} else {
    "[Exists] Applications/DataTools" | Out-File $log -Append
}
$path = Join-Path $base "Ecosystem\Shared_Libraries"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Ecosystem/Shared_Libraries" | Out-File $log -Append
} else {
    "[Exists] Ecosystem/Shared_Libraries" | Out-File $log -Append
}
$path = Join-Path $base "Ecosystem\CrossTier_Engines"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Ecosystem/CrossTier_Engines" | Out-File $log -Append
} else {
    "[Exists] Ecosystem/CrossTier_Engines" | Out-File $log -Append
}
$path = Join-Path $base "Ecosystem\Reflection_Utilities"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Ecosystem/Reflection_Utilities" | Out-File $log -Append
} else {
    "[Exists] Ecosystem/Reflection_Utilities" | Out-File $log -Append
}
$path = Join-Path $base "Ecosystem\Signal_Test_Scripts"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Ecosystem/Signal_Test_Scripts" | Out-File $log -Append
} else {
    "[Exists] Ecosystem/Signal_Test_Scripts" | Out-File $log -Append
}
$path = Join-Path $base "Safeguards\Drift_Audit_Templates"
if (!(Test-Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
    "[Created] Safeguards/Drift_Audit_Templates" | Out-File $log -Append
} else {
    "[Exists] Safeguards/Drift_Audit_Templates" | Out-File $log -Append
}
notepad.exe $log