
# Sync Injected Files into Sapien Intelligence System
$source = "/mnt/data/Sapien_Intelligence_Inject"
$target = "$env:USERPROFILE\Documents\Sapien Intelligence"

# Log file path
$log = Join-Path $target "Logs\Sync_Inject_Log.txt"
"=== Sync Inject Log - $(Get-Date) ===`n" | Out-File $log

# Sync .txt files from source to destination
Get-ChildItem -Path $source -Recurse -File | Where-Object { $_.Extension -eq ".txt" } | ForEach-Object {
    $relativePath = $_.FullName.Substring($source.Length + 1)
    $destPath = Join-Path $target $relativePath

    if (!(Test-Path $destPath)) {
        New-Item -Path (Split-Path $destPath) -ItemType Directory -Force | Out-Null
        Copy-Item -Path $_.FullName -Destination $destPath -Force
        "[Created] $relativePath" | Out-File $log -Append
    } else {
        $existing = Get-Content $destPath -Raw
        if ($existing.Length -lt 50 -or $existing -like "*placeholder*") {
            Copy-Item -Path $_.FullName -Destination $destPath -Force
            "[Overwritten] $relativePath" | Out-File $log -Append
        } else {
            "[Skipped] $relativePath (already contains data)" | Out-File $log -Append
        }
    }
}

notepad.exe $log
