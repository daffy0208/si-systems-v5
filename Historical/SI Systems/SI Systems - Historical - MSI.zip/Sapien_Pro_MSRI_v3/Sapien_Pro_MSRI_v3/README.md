# Sapien Pro MSRI (v3)
This is a Chrome extension for automatic cascade injection in ChatGPT. It monitors output, looks for `#next` triggers, and automatically types "next" to keep the conversation flowing.

Includes:
- Drift detection
- Mirror Tier display overlay
- Works on chat.openai.com

## How to Install
1. Unzip this folder.
2. Open Chrome and go to chrome://extensions/
3. Enable "Developer mode" (top right)
4. Click "Load Unpacked"
5. Select the unzipped folder

You're ready to go.