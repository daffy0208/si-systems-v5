// Determines signal flow direction
function determineFlow(state) {
  // Sample directional logic
  return state.drift_risk === 'critical' ? 'reverse' : 'forward';
}