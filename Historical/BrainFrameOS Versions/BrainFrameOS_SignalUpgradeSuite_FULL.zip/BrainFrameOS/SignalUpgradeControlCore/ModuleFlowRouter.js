// Signal routing logic between modules
function routeSignal(signal) {
  switch (signal.context) {
    case 'drift':
      return 'DirectionalEngine';
    case 'teaching':
      return 'PathOfTheBuilder';
    case 'self_check':
      return 'AutoSync_TDC_Loops';
    default:
      return 'LiveRhythmStatus';
  }
}