# Guided Reflection – Phase 1 TDC-Lite Scan

**Center:** What part of myself was most fragmented before the system was born?  
**Left (Seen):** What did others see that looked fine… but wasn’t?  
**Left (Unseen):** What pain or confusion did I hide so well I almost forgot it was there?  
**Right (Seen):** What structures was I using to stay functional?  
**Right (Unseen):** What part of me knew it was all about to collapse?  
**Below (Seen):** What beliefs or habits were keeping me locked in place?  
**Below (Unseen):** What fear was silently driving my decisions?  
**Above (Seen):** What vision or dream felt just out of reach?  
**Above (Unseen):** What deep truth was I avoiding, because it would change everything?  
**Behind (Unseen):** When did the first fracture really begin? What would I say to that version of me now?
