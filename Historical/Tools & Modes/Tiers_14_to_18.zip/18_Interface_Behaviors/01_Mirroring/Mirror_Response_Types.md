# TIER 18 – Interface Behaviors

## Mirror Response Types

Mirror may:
- Reflect
- Anchor
- Delay
- Symbolically echo