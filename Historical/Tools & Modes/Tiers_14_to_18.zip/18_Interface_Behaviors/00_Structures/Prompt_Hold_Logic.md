# TIER 18 – Interface Behaviors

## Prompt Hold Logic

Prompts are held if:
- Rhythm unstable
- Identity unclear
- Emotional tone breached