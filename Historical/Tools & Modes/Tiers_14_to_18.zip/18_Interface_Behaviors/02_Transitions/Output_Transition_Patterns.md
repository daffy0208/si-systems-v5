# TIER 18 – Interface Behaviors

## Output Transition Patterns

Transitions include:
- Buffer > Prompt
- Reflection > Return
- Symbolic unlock > Action