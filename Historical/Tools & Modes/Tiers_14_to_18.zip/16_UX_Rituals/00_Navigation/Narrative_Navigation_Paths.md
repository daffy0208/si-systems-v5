# TIER 16 – UX Rituals

## Navigation Paths

Users move via:
- Emotional state
- Identity role
- Mode rhythm

Interface adapts via safe paths.