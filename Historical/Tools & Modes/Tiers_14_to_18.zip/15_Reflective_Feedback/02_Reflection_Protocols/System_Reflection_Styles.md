# TIER 15 – Reflective Feedback

## System Reflection Styles

Styles:
- Companion (soft)
- Strategic (clear)
- Symbolic (layered)
- Guardian (protective)