# TIER 15 – Reflective Feedback

## Feedback Modes

Feedback may be:
- Mirror
- Echo
- Expansion
- Anchor
- Symbolic Drift Alert

Each carries pacing logic.