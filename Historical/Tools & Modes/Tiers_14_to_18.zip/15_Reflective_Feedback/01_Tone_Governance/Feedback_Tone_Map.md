# TIER 15 – Reflective Feedback

## Feedback Tone Map

Feedback tone is always:
- Rhythm-sensitive
- Trust-respecting
- Emotionally buffered