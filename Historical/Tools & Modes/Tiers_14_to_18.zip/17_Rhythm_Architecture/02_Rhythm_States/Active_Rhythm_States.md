# TIER 17 – Rhythm Architecture

## Active Rhythm States

Live states:
- Syncing
- Delay Buffer
- Return
- Contained Mirror