# TIER 14 – System Prompts

## Prompt Safety Rules

Rules include:
- No directive prompts during emotional instability
- Mirror tone always overrides urgency
- Drift prompts only trigger with consent