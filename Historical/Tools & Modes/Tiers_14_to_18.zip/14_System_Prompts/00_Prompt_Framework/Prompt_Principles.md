# TIER 14 – System Prompts

## Prompt Principles

Prompts must:
- Reflect user identity
- Respect rhythm pacing
- Trigger resonance, not reaction