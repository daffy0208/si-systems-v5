# TIER 14 – System Prompts

## Identity Prompt Map

Each prompt is filtered through:
- Role context
- Emotional tone
- System rhythm

Mapped to Builder, Seeker, Guardian, Flamekeeper, etc.