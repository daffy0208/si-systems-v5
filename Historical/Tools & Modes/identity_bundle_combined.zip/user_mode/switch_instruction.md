# Switching Between Identity Modes

This identity bundle contains two modes:

- `architect_mode/` – when you are building systems and mapping logic
- `user_mode/` – when you are showing up as yourself for rhythm, truth, reflection

To use in ChatGPT, upload this zip and indicate which mode you'd like to activate.

Example:
> Load identity in user mode — I want reflection, not structure.

Or:
> Activate Architect mode — let's build with full system coherence.
