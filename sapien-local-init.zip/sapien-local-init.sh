#!/bin/bash
# Sapien Local Init Script v1.1.0
source ~/miniconda3/etc/profile.d/conda.sh
conda activate torch121
jupyter lab
