#!/bin/bash
source ~/miniconda3/etc/profile.d/conda.sh
conda activate torch121
jupyter lab
