#!/bin/bash
echo "Checking Jupyter config..."
if [ -f ~/.jupyter/jupyter_notebook_config.py ]; then
  grep -E "token|password|port|open_browser|notebook_dir" ~/.jupyter/jupyter_notebook_config.py
else
  echo "Jupyter config not found."
fi
