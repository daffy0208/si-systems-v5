# Perspective Reflection Template

*To be authored in full detail.*
